#!/usr/bin/env python
# -*- coding: utf-8 -*-

__author__ = 'jenya'





def me_energy(contacts, config, entropies, T, epsilon):
    mysum = 0

    L = len(contacts)

    for i in range(L-1):
        for j in range(i + 1, L):
            temp = config[i:j]  # ??? Предполагается, что это часть списка с i-го по j-й элемент. так ли это???
            mysum = mysum + epsilon*contacts[i][j] * reduce(lambda res, x: res * x, temp, 1)



    for i in range(L):
        mysum = mysum - T * entropies[i]*config[i]


    return mysum
